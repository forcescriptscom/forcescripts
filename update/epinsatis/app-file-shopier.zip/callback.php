<?php
require_once("connect.php");

function go($url) {
    header('Location: '.$url);
    exit();
}

function posit($par, $st = true) {
    if (isset($_POST[$par])) {
        if ($st) {
            return htmlspecialchars(addslashes(trim(strip_tags($_POST[$par]))));
        }
        else {
            return addslashes(trim(strip_tags($_POST[$par])));
        }
    }
    else {
        return false;
    }
}

$id=$_POST['platform_order_id'];
$status=$_POST['status'];

if (isset($_POST["platform_order_id"]) && isset($_POST["status"]) && isset($_POST["installment"]) && isset($_POST["payment_id"]) && isset($_POST["random_nr"]) && isset($_POST["signature"])) {
    $signature  = base64_decode(posit("signature"));

    $data       = posit("random_nr").posit("platform_order_id").posit("total_order_value").posit("currency");
    $expected   = hash_hmac('SHA256', $data, API_SECRET, true);


    if (strcmp($signature, $expected) == 0) {


        if (posit("status") == 'success') {

            $id=$_POST["platform_order_id"];


            $bakiye=$db->prepare("SELECT * FROM bakiye where id=? and firma=? and durum=?");
            $bakiye->execute(array($id,2,0));
            $bky=$bakiye->fetch(PDO::FETCH_ASSOC);

            $upd=$db->prepare("UPDATE bakiye SET
               
               durum=:durum
                  
WHERE id=$id
                  ");
            $gncps=$upd->execute(array(
                'durum'=> 1
            ));

            $kk=$bky['kid'];
            $miktar=$bky['miktar'];

            $kullanici=$db->prepare("SELECT * FROM kullanici where id=?");
            $kullanici->execute(array($kk));
            $user=$kullanici->fetch(PDO::FETCH_ASSOC);

            $bakiye=$user['bakiye'];
            $yenibakiye=$bakiye + $miktar;

            $gnc=$db->prepare("UPDATE kullanici SET
                
                     bakiye=:bakiye

WHERE id=$kk
                     ");
            $guncelle=$gnc->execute(array(

                'bakiye'=>$yenibakiye

            ));

            if ($guncelle and $gncps) {

                if (discordKontrol("yeni_bakiye") == 1){
                    $dcwebhook=discordCek("yeni_bakiye");
                    $kur=getConfig("kur");
                    $mesaj="Bir kullanıcı $miktar $kur yükleme yaptı. **(SHOPİER KREDİ & BANKA KARTI)**";
                    discordMesaj("$dcwebhook", "$mesaj");
                }

                echo "OK";
            }else{
                echo "ODEME_ISLENEMEDI";
            }


            $site=getConfig("url")."/balance";

            go("$site");
        }
        else {
            $site=getConfig("url")."/balance";
            go("$site");
        }
    }

}
else {
    $site=getConfig("url")."/balance";
    go("$site");
}