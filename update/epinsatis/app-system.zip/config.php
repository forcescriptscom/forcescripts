<?php
error_reporting(0);
ini_set('display_errors', 0);
ob_start();


date_default_timezone_set('Europe/Istanbul');
global $db;

if (file_exists("app/system/baglan.php")) {
    require_once 'app/system/baglan.php';
}else{
    $domain=$_SERVER['HTTP_HOST'];
    header("Location:https://$domain/install/kur");
}


$db= new PDO("mysql:host=$host; dbname=$database", "$username", "$password");
$db->exec("SET NAMES 'utf8'");
$db->exec("SET CHARACTER SET utf8");
$db->exec("SET CHARACTER_SET_CONNECTION=utf8");
$db->exec("SET SQL_MODE = ''");

if ( empty($_SESSION['kullanici']) ) {

    if ( isset($_COOKIE['RMB']) and $_COOKIE['RMB'] != 'false' ) {

        $CookieToken = $_COOKIE['RMB'];
        $Browser     = md5($_SERVER['HTTP_USER_AGENT']);
        $time        = time();

        $query = $db->query("SELECT * FROM remember_me WHERE remember_token = '{$CookieToken}' and user_browser = '$Browser' and expired_time > $time ")->fetch(PDO::FETCH_ASSOC);

        if ( $query ) {

            $CookieUser = $query['user_id'];

            $CheckUser = $db->query("SELECT * FROM kullanici WHERE id = '{$CookieUser}' ")->fetch(PDO::FETCH_ASSOC);

            if ( $CheckUser ) {

$_SESSION['kullanici']=$CheckUser['id'];

            } else {

                setcookie("RMB", 'false', time() -3600,'/');
                header("Location:./Login");
                exit;

            }

        } else {

            setcookie("RMB", 'false', time() -3600,'/');
            header("Location:./login");
            exit;

        }

    }
}
include "app/system/function.php";

@header("X-XSS-Protection: 1");
@header("X-Frame-Options: sameorigin");
@header("X-Content-Type-Options: nosniff");
@header("Strict-Transport-Security: max-age=15552000; preload");
@header('X-Powered-By: Force Scripts');





if (!empty($_SESSION['kullanici'])) {
    $dbku=$db->prepare("SELECT * FROM kullanici where id=:id");
    $dbku->execute(array(
        'id'=>$_SESSION['kullanici']
    ));
    $user=$dbku->fetch(PDO::FETCH_ASSOC);

    if ($user['durum'] == 0) {
        $site2=getConfig("url");
        include "app/view/user/banned.php";
        exit();
    }
	
	
	
	if ($user["yetki"] != 2) {
foreach ($_POST as $key => $value) {
    $_POST[$key] = htmlspecialchars($value);
}

foreach ($_GET as $key => $value) {
    $_GET[$key] = htmlspecialchars($value);
}

foreach ($_REQUEST as $key => $value) {
    $_REQUEST[$key] = htmlspecialchars($value);
}

foreach ($_COOKIE as $key => $value) {
    $_COOKIE[$key] = htmlspecialchars($value);
}

if (isset($_SESSION)) {
    foreach ($_SESSION as $key => $value) {
        $_SESSION[$key] = htmlspecialchars($value);
    }
}
}
	
	

}else{
	

	
	foreach ($_POST as $key => $value) {
    $_POST[$key] = htmlspecialchars($value);
}

foreach ($_GET as $key => $value) {
    $_GET[$key] = htmlspecialchars($value);
}

foreach ($_REQUEST as $key => $value) {
    $_REQUEST[$key] = htmlspecialchars($value);
}

foreach ($_COOKIE as $key => $value) {
    $_COOKIE[$key] = htmlspecialchars($value);
}

if (isset($_SESSION)) {
    foreach ($_SESSION as $key => $value) {
        $_SESSION[$key] = htmlspecialchars($value);
    }
}
	
}



$domain=$_SERVER['HTTP_HOST'];
$site=file_get_contents("https://forcescripts.com/lisans/epin.php?domain=$domain");

if ($site == "yok"){
    echo "$domain Adresiniz için mevcut lisans bulunamamıştır. forcescripts.com Adresinden lisans satın alabilirsiniz.";
    exit();
}


if($_SERVER['REQUEST_URI'] == "/paytr/callback"){
    $site=getConfig("url");

    if(odemeKontrol("4") == 0) {
        header("Location:$site/balance");
        exit();
    }

    $post = $_POST;

    ####################### DÜZENLEMESİ ZORUNLU ALANLAR #######################
    #
    ## API Entegrasyon Bilgileri - Mağaza paneline giriş yaparak BİLGİ sayfasından alabilirsiniz.
    $merchant_key   = paytrCek("key2");
    $merchant_salt  = paytrCek("key3");
    ###########################################################################

    ####### Bu kısımda herhangi bir değişiklik yapmanıza gerek yoktur. #######
    #
    ## POST değerleri ile hash oluştur.
    $hash = base64_encode( hash_hmac('sha256', $post['merchant_oid'].$merchant_salt.$post['status'].$post['total_amount'], $merchant_key, true) );
    #
    ## Oluşturulan hash'i, paytr'dan gelen post içindeki hash ile karşılaştır (isteğin paytr'dan geldiğine ve değişmediğine emin olmak için)
    ## Bu işlemi yapmazsanız maddi zarara uğramanız olasıdır.
    if( $hash != $post['hash'] )
        die('PAYTR notification failed: bad hash');
    ###########################################################################

    ## BURADA YAPILMASI GEREKENLER
    ## 1) Siparişin durumunu $post['merchant_oid'] değerini kullanarak veri tabanınızdan sorgulayın.
    ## 2) Eğer sipariş zaten daha önceden onaylandıysa veya iptal edildiyse  echo "OK"; exit; yaparak sonlandırın.

    /* Sipariş durum sorgulama örnek
       $durum = SQL
       if($durum == "onay" || $durum == "iptal"){
            echo "OK";
            exit;
        }
     */

    if( $post['status'] == 'success' ) { ## Ödeme Onaylandı

        $id=$post['merchant_oid'];

        $bakiye=$db->prepare("SELECT * FROM bakiye where id=? and firma=? and durum=?");
        $bakiye->execute(array($id,4,0));
        $bky=$bakiye->fetch(PDO::FETCH_ASSOC);

        $upd=$db->prepare("UPDATE bakiye SET
               
               durum=:durum
                  
WHERE id=$id
                  ");
        $gncps=$upd->execute(array(
            'durum'=> 1
        ));

        $kk=$bky['kid'];
        $miktar=$bky['miktar'];

        $kullanici=$db->prepare("SELECT * FROM kullanici where id=?");
        $kullanici->execute(array($kk));
        $user=$kullanici->fetch(PDO::FETCH_ASSOC);

        $bakiye=$user['bakiye'];
        $yenibakiye=$bakiye + $miktar;

        $gnc=$db->prepare("UPDATE kullanici SET
                
                     bakiye=:bakiye

WHERE id=$kk
                     ");
        $guncelle=$gnc->execute(array(

            'bakiye'=>$yenibakiye

        ));

        if (discordKontrol("yeni_bakiye") == 1){
            $dcwebhook=discordCek("yeni_bakiye");
            $kur=getConfig("kur");
            $mesaj="Bir kullanıcı $miktar $kur yükleme yaptı. **(PAYTR KREDİ & BANKA KARTI)**";
            discordMesaj("$dcwebhook", "$mesaj");
        }


    } else { ## Ödemeye Onay Verilmedi

        $id=$post['merchant_oid'];

        $bakiye=$db->prepare("SELECT * FROM bakiye where id=? and firma=? and durum=?");
        $bakiye->execute(array($id,4,0));
        $bky=$bakiye->fetch(PDO::FETCH_ASSOC);

        $upd=$db->prepare("UPDATE bakiye SET
               
               durum=:durum
                  
WHERE id=$id
                  ");
        $gncps=$upd->execute(array(
            'durum'=> 2
        ));

    }

    ## Bildirimin alındığını PayTR sistemine bildir.
    echo "OK";


    exit();
}

if($_SERVER['REQUEST_URI'] == "/paytr") {
    $site=getConfig("url");

    if (empty($_SESSION['kullanici'])) {
        header("Location:$site/login");
        exit();
    }

    $bakiye=$db->prepare("SELECT * FROM bakiye where kid=:kid and firma=:firma and durum=:durum order by id DESC limit 1");
    $bakiye->execute(array(

        'kid'=>$_SESSION['kullanici'],
        'firma'=>4,
        'durum'=>0

    ));
    $bky=$bakiye->fetch(PDO::FETCH_ASSOC);

    $kullanici=$db->prepare("SELECT * FROM kullanici where id=?");
    $kullanici->execute(array($_SESSION['kullanici']));
    $user=$kullanici->fetch(PDO::FETCH_ASSOC);

    $tutar=$bky['odenen']*100;
    $ordid=$bky['id'];
    $ad=$user['ad'];
    $soyad=$user['soyad'];
    $telefon=$user['telefon'];
    $odenen=$bky['odenen'];

    if (odemeKontrol("4") == 0) {
        header("Location:$site/balance");
        exit();
    }

    $merchant_id    = paytrCek("key1");
    $merchant_key   = paytrCek("key2");
    $merchant_salt  = paytrCek("key3");
    #
    ## Müşterinizin sitenizde kayıtlı veya form vasıtasıyla aldığınız eposta adresi
    $email = $user['eposta'];
    #
    ## Tahsil edilecek tutar.
    $payment_amount = $tutar; //9.99 için 9.99 * 100 = 999 gönderilmelidir.
    #
    ## Sipariş numarası: Her işlemde benzersiz olmalıdır!! Bu bilgi bildirim sayfanıza yapılacak bildirimde geri gönderilir.
    $merchant_oid = "$ordid";
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız ad ve soyad bilgisi
    $user_name = $ad." ".$soyad;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız adres bilgisi
    $user_address = "İstanbul Turkey";
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız telefon bilgisi
    $user_phone = $telefon;
    #
    ## Başarılı ödeme sonrası müşterinizin yönlendirileceği sayfa
    ## !!! Bu sayfa siparişi onaylayacağınız sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
    ## !!! Siparişi onaylayacağız sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
    $merchant_ok_url = $site."/profile";
    #
    ## Ödeme sürecinde beklenmedik bir hata oluşması durumunda müşterinizin yönlendirileceği sayfa
    ## !!! Bu sayfa siparişi iptal edeceğiniz sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
    ## !!! Siparişi iptal edeceğiniz sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
    $merchant_fail_url = $site."/balance";
    #
    ## Müşterinin sepet/sipariş içeriği
    #
    $user_basket = base64_encode(json_encode(array(
        array("Bakiye Yükleme", "$odenen", 1)
    )));

    ## Kullanıcının IP adresi
    if( isset( $_SERVER["HTTP_CLIENT_IP"] ) ) {
        $ip = $_SERVER["HTTP_CLIENT_IP"];
    } elseif( isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
        $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ip = $_SERVER["REMOTE_ADDR"];
    }

    ## !!! Eğer bu örnek kodu sunucuda değil local makinanızda çalıştırıyorsanız
    ## buraya dış ip adresinizi (https://www.whatismyip.com/) yazmalısınız. Aksi halde geçersiz paytr_token hatası alırsınız.
    $user_ip=$ip;
    ##

    ## İşlem zaman aşımı süresi - dakika cinsinden
    $timeout_limit = "30";

    ## Hata mesajlarının ekrana basılması için entegrasyon ve test sürecinde 1 olarak bırakın. Daha sonra 0 yapabilirsiniz.
    $debug_on = 1;

    ## Mağaza canlı modda iken test işlem yapmak için 1 olarak gönderilebilir.
    $test_mode = 0;

    $no_installment = 0; // Taksit yapılmasını istemiyorsanız, sadece tek çekim sunacaksanız 1 yapın

    ## Sayfada görüntülenecek taksit adedini sınırlamak istiyorsanız uygun şekilde değiştirin.
    ## Sıfır (0) gönderilmesi durumunda yürürlükteki en fazla izin verilen taksit geçerli olur.
    $max_installment = 0;

    $currency = "TL";

    ####### Bu kısımda herhangi bir değişiklik yapmanıza gerek yoktur. #######
    $hash_str = $merchant_id .$user_ip .$merchant_oid .$email .$payment_amount .$user_basket.$no_installment.$max_installment.$currency.$test_mode;
    $paytr_token=base64_encode(hash_hmac('sha256',$hash_str.$merchant_salt,$merchant_key,true));
    $post_vals=array(
        'merchant_id'=>$merchant_id,
        'user_ip'=>$user_ip,
        'merchant_oid'=>$merchant_oid,
        'email'=>$email,
        'payment_amount'=>$payment_amount,
        'paytr_token'=>$paytr_token,
        'user_basket'=>$user_basket,
        'debug_on'=>$debug_on,
        'no_installment'=>$no_installment,
        'max_installment'=>$max_installment,
        'user_name'=>$user_name,
        'user_address'=>$user_address,
        'user_phone'=>$user_phone,
        'merchant_ok_url'=>$merchant_ok_url,
        'merchant_fail_url'=>$merchant_fail_url,
        'timeout_limit'=>$timeout_limit,
        'currency'=>$currency,
        'test_mode'=>$test_mode
    );

    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.paytr.com/odeme/api/get-token");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1) ;
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_vals);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);

    // XXX: DİKKAT: lokal makinanızda "SSL certificate problem: unable to get local issuer certificate" uyarısı alırsanız eğer
    // aşağıdaki kodu açıp deneyebilirsiniz. ANCAK, güvenlik nedeniyle sunucunuzda (gerçek ortamınızda) bu kodun kapalı kalması çok önemlidir!
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $result = @curl_exec($ch);

    if(curl_errno($ch))
        die("PAYTR IFRAME connection error. err:".curl_error($ch));

    curl_close($ch);

    $result=json_decode($result,1);

    if($result['status']=='success')
        $token=$result['token'];
    else
        die("PAYTR IFRAME failed. reason:".$result['reason']);

    ?>

    <script src="https://www.paytr.com/js/iframeResizer.min.js"></script>
    <iframe src="https://www.paytr.com/odeme/guvenli/<?php echo $token;?>" id="paytriframe" frameborder="0" scrolling="no" style="width: 100%;"></iframe>
    <script>iFrameResize({},'#paytriframe');</script>

    <?php



    exit();
}

if($_SERVER['REQUEST_URI'] == "/post/205564/021587") {
 
     $dbku=$db->prepare("SELECT * FROM kullanici where id=:id");
    $dbku->execute(array(
        'id'=>$_SESSION['kullanici']
    ));
    $user=$dbku->fetch(PDO::FETCH_ASSOC);

    if ($user['yetki'] != 2) {
        exit();
    }
    
    
    $sitekey=$_POST['site_key'];
    $secretkey=$_POST['secret_key'];
    
    $ekle=$db->prepare("UPDATE config SET
    
    value=:value
    
    WHERE name='h_site_key'
    ");
    $a=$ekle->execute(array(
        'value'=>$sitekey
        
        ));
    
     $ekle=$db->prepare("UPDATE config SET
    
    value=:value
    
    WHERE name='h_secret_key'
    ");
    $asd=$ekle->execute(array(
        'value'=>$secretkey
        
        ));
    
    if($a and $asd) {
            $site=getConfig("url");
            header("Location:$site/admin/settings/login-register?durum=basarili");
    }else{
            $site=getConfig("url");
            header("Location:$site/admin/settings/login-register?durum=basarisiz");     
    }
    
    exit();
    
}

if($_SERVER['REQUEST_URI'] == "/login/giris") {
    
    if(!empty(getConfig('h_site_key')) and !empty(getConfig('h_secret_key'))) {
    if(isset($_POST['h-captcha-response']) && !empty($_POST['h-captcha-response'])){
        
        
          $data = array(
              'secret' => getConfig('h_secret_key'),
              'response' => $_POST['h-captcha-response']
          );
        $verify = curl_init();
        curl_setopt($verify, CURLOPT_URL,   "https://hcaptcha.com/siteverify");
        curl_setopt($verify, CURLOPT_POST, true);
        curl_setopt($verify, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($verify, CURLOPT_RETURNTRANSFER, true);
        $verifyResponse = curl_exec($verify);
        $responseData = json_decode($verifyResponse);
        
        if($responseData->success) {
            
            $eposta=$_POST['eposta'];
    $ss=$_POST['sifre'];
    $sifre=hash("sha256", "$ss");

    if (filter_var($eposta, FILTER_VALIDATE_EMAIL)) {
        //email

        $grskn=$db->prepare("SELECT * FROM kullanici where eposta=:eposta and sifre=:sifre");
        $grskn->execute(array(
            'eposta'=>$eposta,
            'sifre'=>$sifre
        ));
        $kontrol=$grskn->fetch(PDO::FETCH_ASSOC);

        $saykontrol=$grskn->rowCount();

        if ($saykontrol != 1) {
            header("Location:../../login?durum=yanlis");
        }else{

            if (discordKontrol('giris') == 1) {
                if (!empty(discordCek('giris'))) {
                    $mesaj=$kontrol['ad']." ".$kontrol['soyad']." Adlı kullanıcı giriş yaptı.";
                    $link=discordCek("giris");
                    discordMesaj("$link", "$mesaj");
                }
            }

            $_SESSION['kullanici']=$kontrol['id'];

            $id=$kontrol['id'];

            $upd=$db->prepare("UPDATE kullanici SET
            
                     son_ip=:son_ip,
                     son_zaman=:son_zaman
                     
                     WHERE id=$id
                     ");
            $upd->execute(array(
                'son_ip'=>$_SERVER['REMOTE_ADDR'],
                'son_zaman'=>date('H:i:s d.m.Y')
            ));

            if (isset($_POST['remember-me'])) {
                $UserID = $kontrol['id'];
                $delete = $db->prepare("DELETE FROM remember_me WHERE user_id = '$UserID' ");

                $NewToken = bin2hex(openssl_random_pseudo_bytes(32));

                $Insert2 = $db->prepare("INSERT into remember_me SET
        user_id =:bir,
        remember_token =:iki,
        expired_time =:uc,
        user_browser =:dort");
                $insert = $Insert2->execute(array(
                    "bir" => $UserID,
                    "iki" => $NewToken,
                    "uc" => time()+604800,
                    'dort' => md5($_SERVER['HTTP_USER_AGENT'])

                ));

                setcookie("RMB", $NewToken, time() + 604801,'/');
            }

            header("Location:../../login?durum=basarili");
            exit();

        }

    } else {

        $grskn=$db->prepare("SELECT * FROM kullanici where kullanici_adi=:kullanici_adi and sifre=:sifre");
        $grskn->execute(array(
            'kullanici_adi'=>$eposta,
            'sifre'=>$sifre
        ));
        $kontrol=$grskn->fetch(PDO::FETCH_ASSOC);

        $saykontrol=$grskn->rowCount();

        if ($saykontrol != 1) {
            header("Location:../../login?durum=yanlis");
        }else{

            if (discordKontrol('giris') == 1) {
                if (!empty(discordCek('giris'))) {
                    $mesaj=$kontrol['ad']." ".$kontrol['soyad']." Adlı kullanıcı giriş yaptı.";
                    $link=discordCek('giris');
                    discordMesaj("$link", "$mesaj");
                }
            }

            $_SESSION['kullanici']=$kontrol['id'];

            $id=$kontrol['id'];

            $upd=$db->prepare("UPDATE kullanici SET
            
                     son_ip=:son_ip,
                     son_zaman=:son_zaman
                     
                     WHERE id=$id
                     ");
            $upd->execute(array(
                'son_ip'=>$_SERVER['REMOTE_ADDR'],
                'son_zaman'=>date('H:i:s d.m.Y')
            ));

            if (isset($_POST['remember-me'])) {



                $UserID = $kontrol['id'];
                $delete = $db->prepare("DELETE FROM remember_me WHERE user_id = '$UserID' ");

                $NewToken = bin2hex(openssl_random_pseudo_bytes(32));

                $Insert2 = $db->prepare("INSERT INTO remember_me SET
        user_id =:bir,
        remember_token =:iki,
        expired_time =:uc,
        user_browser =:dort");
                $insert = $Insert2->execute(array(
                    "bir" => $UserID,
                    "iki" => $NewToken,
                    "uc" => time()+604800,
                    'dort' => md5($_SERVER['HTTP_USER_AGENT'])

                ));

                setcookie("RMB", $NewToken, time() + 604801,'/');
            }

            header("Location:../../login?durum=basarili");
            exit();

        }


    }
            
            
            
        }else{
            $site=getConfig("url");
            header("Location:$site/login?durum=captcha"); 
        }
        
    }else{
            $site=getConfig("url");
            header("Location:$site/login?durum=boscaptcha"); 
    }
        
        
    }else{
        
        $eposta=$_POST['eposta'];
    $ss=$_POST['sifre'];
    $sifre=hash("sha256", "$ss");

    if (filter_var($eposta, FILTER_VALIDATE_EMAIL)) {
        //email

        $grskn=$db->prepare("SELECT * FROM kullanici where eposta=:eposta and sifre=:sifre");
        $grskn->execute(array(
            'eposta'=>$eposta,
            'sifre'=>$sifre
        ));
        $kontrol=$grskn->fetch(PDO::FETCH_ASSOC);

        $saykontrol=$grskn->rowCount();

        if ($saykontrol != 1) {
            header("Location:../../login?durum=yanlis");
        }else{

            if (discordKontrol('giris') == 1) {
                if (!empty(discordCek('giris'))) {
                    $mesaj=$kontrol['ad']." ".$kontrol['soyad']." Adlı kullanıcı giriş yaptı.";
                    $link=discordCek("giris");
                    discordMesaj("$link", "$mesaj");
                }
            }

            $_SESSION['kullanici']=$kontrol['id'];

            $id=$kontrol['id'];

            $upd=$db->prepare("UPDATE kullanici SET
            
                     son_ip=:son_ip,
                     son_zaman=:son_zaman
                     
                     WHERE id=$id
                     ");
            $upd->execute(array(
                'son_ip'=>$_SERVER['REMOTE_ADDR'],
                'son_zaman'=>date('H:i:s d.m.Y')
            ));

            if (isset($_POST['remember-me'])) {
                $UserID = $kontrol['id'];
                $delete = $db->prepare("DELETE FROM remember_me WHERE user_id = '$UserID' ");

                $NewToken = bin2hex(openssl_random_pseudo_bytes(32));

                $Insert2 = $db->prepare("INSERT into remember_me SET
        user_id =:bir,
        remember_token =:iki,
        expired_time =:uc,
        user_browser =:dort");
                $insert = $Insert2->execute(array(
                    "bir" => $UserID,
                    "iki" => $NewToken,
                    "uc" => time()+604800,
                    'dort' => md5($_SERVER['HTTP_USER_AGENT'])

                ));

                setcookie("RMB", $NewToken, time() + 604801,'/');
            }

            header("Location:../../login?durum=basarili");
            exit();

        }

    } else {

        $grskn=$db->prepare("SELECT * FROM kullanici where kullanici_adi=:kullanici_adi and sifre=:sifre");
        $grskn->execute(array(
            'kullanici_adi'=>$eposta,
            'sifre'=>$sifre
        ));
        $kontrol=$grskn->fetch(PDO::FETCH_ASSOC);

        $saykontrol=$grskn->rowCount();

        if ($saykontrol != 1) {
            header("Location:../../login?durum=yanlis");
        }else{

            if (discordKontrol('giris') == 1) {
                if (!empty(discordCek('giris'))) {
                    $mesaj=$kontrol['ad']." ".$kontrol['soyad']." Adlı kullanıcı giriş yaptı.";
                    $link=discordCek('giris');
                    discordMesaj("$link", "$mesaj");
                }
            }

            $_SESSION['kullanici']=$kontrol['id'];

            $id=$kontrol['id'];

            $upd=$db->prepare("UPDATE kullanici SET
            
                     son_ip=:son_ip,
                     son_zaman=:son_zaman
                     
                     WHERE id=$id
                     ");
            $upd->execute(array(
                'son_ip'=>$_SERVER['REMOTE_ADDR'],
                'son_zaman'=>date('H:i:s d.m.Y')
            ));

            if (isset($_POST['remember-me'])) {



                $UserID = $kontrol['id'];
                $delete = $db->prepare("DELETE FROM remember_me WHERE user_id = '$UserID' ");

                $NewToken = bin2hex(openssl_random_pseudo_bytes(32));

                $Insert2 = $db->prepare("INSERT INTO remember_me SET
        user_id =:bir,
        remember_token =:iki,
        expired_time =:uc,
        user_browser =:dort");
                $insert = $Insert2->execute(array(
                    "bir" => $UserID,
                    "iki" => $NewToken,
                    "uc" => time()+604800,
                    'dort' => md5($_SERVER['HTTP_USER_AGENT'])

                ));

                setcookie("RMB", $NewToken, time() + 604801,'/');
            }

            header("Location:../../login?durum=basarili");
            exit();

        }


    }
        
        
    }



exit();

}


?>