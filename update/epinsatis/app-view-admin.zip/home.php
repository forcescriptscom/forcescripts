<?php include 'header.php'; ?>
    <!-- start page content wrapper-->
    <div class="page-content-wrapper">
        <!-- start page content-->
        <div class="page-content">

            <!--start breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">Admin Panel</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0 align-items-center">
                            <li class="breadcrumb-item"><a href="javascript:;"><ion-icon name="home-outline"></ion-icon></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Anasayfa</li>
                        </ol>
                    </nav>
                </div>

            </div>
            <!--end breadcrumb-->


            <div style="background-color:black;color:white" class="row">
                <p>
                    <br>
Son Güncelleme Detayları v1.0.7;<br>
<br>
Giriş sayfası için bot doğrulaması eklendi. Üyelerin veya yetkililerin hesaplarına zorla giriş olmaması için <code><a href="<?php echo getConfig("url"); ?>/admin/settings/login-register">TIKLAYARAK</a></code> ayarlamalarınızı yapın.
</p>
</div>

            <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 row-cols-xxl-3">

                <?php
                $gun = date('H:i:s d.m.Y');


                //GÜNLÜK YENİ KAYIT
                $gunlukyenikayit = $db->prepare("SELECT COUNT(*) FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m-%d') = :gun");
                $gunlukyenikayit->execute(array('gun' => date('Y-m-d', strtotime($gun))));
                $gunlukkayit = $gunlukyenikayit->fetchColumn();

                $toplamkayit = $db->query("SELECT COUNT(*) FROM kullanici")->fetchColumn();

                $orankk = ($gunlukkayit / $toplamkayit) * 100;


                // GÜNLÜK SİPARİŞ
                $gunlukyenisiparis = $db->prepare("SELECT COUNT(*) FROM siparis WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m-%d') = :gun");
                $gunlukyenisiparis->execute(array('gun' => date('Y-m-d', strtotime($gun))));
                $gunluksiparis = $gunlukyenisiparis->fetchColumn();

                $toplamsiparis = $db->query("SELECT COUNT(*) FROM siparis")->fetchColumn();

                $oransp = ($gunluksiparis / $toplamsiparis) * 100;


                //GÜNLÜK ZİYARET

                $unlukyeniziyaret = $db->prepare("SELECT COUNT(*) FROM ziyaret WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%h:%i:%s %d.%m.%Y'), '%Y-%m-%d') = :gun");
                $unlukyeniziyaret->execute(array('gun' => date('Y-m-d', strtotime($gun))));
                $gunlukziyaret = $unlukyeniziyaret->fetchColumn();

                $toplamziyaret = $db->query("SELECT COUNT(*) FROM ziyaret")->fetchColumn();

                $oranzz = ($gunlukziyaret / $toplamziyaret) * 100;



                // GÜNLÜK BAKİYE YATIRMA

                $gunlukbakiye = $db->prepare("SELECT IFNULL(SUM(odenen), 0) AS toplam_odenen FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m-%d') = DATE_FORMAT(STR_TO_DATE(:zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m-%d') AND durum = :durum");
                $gunlukbakiye->execute(array(
                    'zaman' => $gun,
                    'durum' => 1
                ));
                $gunlukbakiyee = $gunlukbakiye->fetch(PDO::FETCH_ASSOC)['toplam_odenen'];

                $toplambakiye = $db->prepare("SELECT IFNULL(SUM(odenen), 0) AS toplam_bakiye FROM bakiye WHERE durum = :durum");
                $toplambakiye->execute(array(
                    'durum' => 1
                ));
                $toplambakiyee = $toplambakiye->fetch(PDO::FETCH_ASSOC)['toplam_bakiye'];

                $oranbk = ($gunlukbakiyee / $toplambakiyee) * 100;










                ?>

                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="widget-icon-2 bg-gradient-info text-white">
                                    <ion-icon name="bag-handle-sharp"></ion-icon>
                                </div>
                                <div class="fs-5 ms-auto"><ion-icon name="ellipsis-horizontal-sharp"></ion-icon></div>
                            </div>
                            <h5 class="my-3">Günlük Satış</h5>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-gradient-info" role="progressbar" style="width: <?php echo $oransp ?>%"></div>
                            </div>
                            <p class="mb-0 mt-2"><?php echo $gunluksiparis ?><span class="float-end text-success">+<?php echo $oransp ?>%</span></p>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="widget-icon-2 bg-gradient-danger text-white">
                                    <ion-icon name="card-sharp"></ion-icon>
                                </div>
                                <div class="fs-5 ms-auto"><ion-icon name="ellipsis-horizontal-sharp"></ion-icon></div>
                            </div>
                            <h5 class="my-3">Günlük Bakiye Yükleme</h5>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-gradient-danger" role="progressbar" style="width: <?php echo $oranbk ?>%"></div>
                            </div>
                            <p class="mb-0 mt-2"><?php echo $gunlukbakiyee ?> <?=getConfig("kur")?><span class="float-end text-success">+<?php echo $oranbk ?>%</span></p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="widget-icon-2 bg-gradient-success text-white">
                                    <i class="fi fi-rr-ban"></i>
                                </div>
                                <div class="fs-5 ms-auto"><ion-icon name="ellipsis-horizontal-sharp"></ion-icon></div>
                            </div>
                            <h5 class="my-3">Banlanılan IP Sayısı</h5>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-gradient-success" role="progressbar" style="width: 0%"></div>
                            </div>
                            <p class="mb-0 mt-2"><?php

                                $dosya=file("ip-bans.txt");
                                $bansayi=count($dosya);

                                echo $bansayi;

                                ?><span class="float-end text-danger">(ip-bans.txt)</span></p>
                        </div>
                    </div>
                </div>



                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="widget-icon-2 bg-gradient-purple text-white">
                                    <ion-icon name="people-sharp"></ion-icon>
                                </div>
                                <div class="fs-5 ms-auto"><ion-icon name="ellipsis-horizontal-sharp"></ion-icon></div>
                            </div>
                            <h5 class="my-3">Günlük Yeni Kayıt</h5>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-gradient-purple" role="progressbar" style="width: <?php echo $orankk; ?>%"></div>
                            </div>
                            <p class="mb-0 mt-2"><?php echo $gunlukkayit; ?><span class="float-end text-success">+<?php echo $orankk; ?>%</span></p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="widget-icon-2 bg-gradient-branding text-white">
                                    <ion-icon name="pie-chart-sharp"></ion-icon>
                                </div>
                                <div class="fs-5 ms-auto"><ion-icon name="ellipsis-horizontal-sharp"></ion-icon></div>
                            </div>
                            <h5 class="my-3">Günlük Ziyaret</h5>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-gradient-branding" role="progressbar" style="width: <?php echo $oranzz ?>%"></div>
                            </div>
                            <p class="mb-0 mt-2"><?php echo $gunlukziyaret ?><span class="float-end text-success">+<?php echo $oranzz ?>%</span></p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card radius-10">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="widget-icon-2 bg-gradient-warning text-white">
                                    <i class="fi fi-rr-coins"></i>
                                </div>
                                <div class="fs-5 ms-auto"><ion-icon name="ellipsis-horizontal-sharp"></ion-icon></div>
                            </div>
                            <h5 class="my-3">Toplam Üye</h5>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-gradient-warning" role="progressbar" style="width: 65%"></div>
                            </div>
                            <p class="mb-0 mt-2"><?php echo $toplamkayit ?><span class="float-end text-success">+7.6%</span></p>
                        </div>
                    </div>
                </div>
            </div>





            <div class="card radius-10 overflow-hidden w-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <h6 class="mb-0">Yıllık Bakiye/Kayıt Performansı</h6>
                        <div class="dropdown options ms-auto">
                            <div class="dropdown-toggle dropdown-toggle-nocaret" data-bs-toggle="dropdown">
                                <ion-icon name="ellipsis-horizontal-sharp"></ion-icon>
                            </div>
                        </div>
                    </div>
                    <div class="chart-container1">
                        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                        <div style="height: 100%; width: 100%;" id="chart_div"></div>
                    </div>
                </div>
            </div>

            <?php

            $currentYear = date('Y');

            // Ocak ayı için verileri toplama
            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-01');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $ocakbakiye = $result['toplam_miktar'];

            if ($ocakbakiye == null){
                $ocakbakiye=0;
            }


            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-02');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $subatbakiye = $result['toplam_miktar'];

            if ($subatbakiye == null){
                $subatbakiye=0;
            }


            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-03');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $martbakiye = $result['toplam_miktar'];

            if ($martbakiye == null){
                $martbakiye=0;
            }

            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-04');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $nisanbakiye = $result['toplam_miktar'];

            if ($nisanbakiye == null){
                $nisanbakiye=0;
            }


            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-05');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $mayisbakiye = $result['toplam_miktar'];

            if ($mayisbakiye == null){
                $mayisbakiye=0;
            }


            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-06');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $haziranbakiye = $result['toplam_miktar'];

            if ($haziranbakiye == null){
                $haziranbakiye=0;
            }

            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-07');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $temmuzbakiye = $result['toplam_miktar'];

            if ($temmuzbakiye == null){
                $temmuzbakiye=0;
            }


            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-08');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $agustosbakiye = $result['toplam_miktar'];

            if ($agustosbakiye == null){
                $agustosbakiye=0;
            }

            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-09');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $eylulbakiye = $result['toplam_miktar'];

            if ($eylulbakiye == null){
                $eylulbakiye=0;
            }


            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-10');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $ekimbakiye = $result['toplam_miktar'];

            if ($ekimbakiye == null){
                $ekimbakiye=0;
            }

            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-11');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $kasimbakiye = $result['toplam_miktar'];

            if ($kasimbakiye == null){
                $kasimbakiye=0;
            }

            $query = "SELECT SUM(miktar) AS toplam_miktar FROM bakiye WHERE DATE_FORMAT(STR_TO_DATE(zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date and durum=1";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-12');
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $aralikbakiye = $result['toplam_miktar'];

            if ($aralikbakiye == null){
                $aralikbakiye=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-01');
            $stmt->execute();
            $ocakkayit = $stmt->rowCount();


                        if ($ocakkayit == null){
                            $ocakkayit=0;
                        }



            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-02');
            $stmt->execute();
            $subatkayit = $stmt->rowCount();


            if ($subatkayit == null){
                $subatkayit=0;
            }



            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-03');
            $stmt->execute();
            $martkayit = $stmt->rowCount();


            if ($martkayit == null){
                $martkayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-04');
            $stmt->execute();
            $nisankayit = $stmt->rowCount();


            if ($nisankayit == null){
                $nisankayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-05');
            $stmt->execute();
            $mayiskayit = $stmt->rowCount();


            if ($mayiskayit == null){
                $mayiskayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-06');
            $stmt->execute();
            $hazirankayit = $stmt->rowCount();


            if ($hazirankayit == null){
                $hazirankayit=0;
            }



            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-07');
            $stmt->execute();
            $temmuzkayit = $stmt->rowCount();


            if ($temmuzkayit == null){
                $temmuzkayit=0;
            }




            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-08');
            $stmt->execute();
            $agustoskayit = $stmt->rowCount();


            if ($agustoskayit == null){
                $agustoskayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-09');
            $stmt->execute();
            $eylulkayit = $stmt->rowCount();


            if ($eylulkayit == null){
                $eylulkayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-10');
            $stmt->execute();
            $ekimkayit = $stmt->rowCount();


            if ($ekimkayit == null){
                $ekimkayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-11');
            $stmt->execute();
            $kasimkayit = $stmt->rowCount();


            if ($kasimkayit == null){
                $kasimkayit=0;
            }


            $query="SELECT * FROM kullanici WHERE DATE_FORMAT(STR_TO_DATE(ilk_zaman, '%H:%i:%s %d.%m.%Y'), '%Y-%m') = :date";
            $stmt = $db->prepare($query);
            $stmt->bindValue(':date', $currentYear . '-12');
            $stmt->execute();
            $aralikkayit = $stmt->rowCount();


            if ($aralikkayit == null){
                $aralikkayit=0;
            }

            ?>


            <script type="text/javascript">
                google.charts.load('current', {'packages':['corechart']});
                google.charts.setOnLoadCallback(drawChart);

                function drawChart() {
                    var data = google.visualization.arrayToDataTable([
                        ['Year', 'Bakiye Yükleme', 'Kayıt'],
                        ['Ocak',  <?php echo $ocakbakiye ?>,      <?php echo $ocakkayit ?>],
                        ['Şubat',  <?php echo $subatbakiye ?>,      <?php echo $subatkayit ?>],
                        ['Mart',  <?php echo $martbakiye ?>,       <?php echo $martkayit ?>],
                        ['Nisan',  <?php echo $nisanbakiye ?>,      <?php echo $nisankayit ?>],
                        ['Mayıs',  <?php echo $mayisbakiye ?>,      <?php echo $mayiskayit ?>],
                        ['Haziran',  <?php echo $haziranbakiye ?>,      <?php echo $hazirankayit ?>],
                        ['Temmuz',  <?php echo $temmuzbakiye ?>,      <?php echo $temmuzkayit ?>],
                        ['Ağustos',  <?php echo $agustosbakiye ?>,      <?php echo $agustoskayit ?>],
                        ['Eylül',  <?php echo $eylulbakiye ?>,      <?php echo $eylulkayit ?>],
                        ['Ekim',  <?php echo $ekimbakiye ?>,      <?php echo $ekimkayit ?>],
                        ['Kasım',  <?php echo $kasimbakiye ?>,      <?php echo $kasimkayit ?>],
                        ['Aralık',  <?php echo $aralikbakiye ?>,      <?php echo $aralikkayit ?>]
                    ]);

                    var options = {
                        title: 'Bakiye/Kayıt Performansı',
                        curveType: 'function',
                        backgroundColor: '#FFD700',
                        legend: { position: 'bottom' }
                    };

                    var chart = new google.visualization.LineChart(document.getElementById('chart_div'));

                    chart.draw(data, options);
                }
            </script>



            <div class="card radius-10">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <h6 class="mb-0">Ürünler</h6>
                        <div class="fs-5 ms-auto dropdown">

                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>

                            <tr>
                                <th>ID</th>
                                <th>Başlık</th>
                                <th>Kategori</th>
                                <th>Stok</th>
                                <th>Fiyat</th>
                                <th></th>
                            </tr>

                            </thead>
                            <tbody>
                            <?php

                            $u=$db->prepare("SELECT * FROM epin");
                            $u->execute();

                            while($epin=$u->fetch(PDO::FETCH_ASSOC)) {
                                $k=$db->prepare("SELECT * FROM epin_kategori where id=?");
                                $k->execute(array($epin['kategori']));
                                $kategori=$k->fetch(PDO::FETCH_ASSOC);


                                ?>
                                <tr>
                                    <td><?php echo $epin['id'] ?></td>
                                    <td><?php echo $epin['baslik'] ?></td>
                                    <td><?php echo $kategori['baslik'] ?></td>
                                    <td><?php echo stokSay($epin['hesap']) ?></td>
                                    <td><?php echo $epin['tutar'] ?> <?=getConfig("kur")?></td>
                                    <td>
                                        <a href="<?=getConfig("url")?>/epin/<?php  echo replace_tr($epin['baslik']); ?>/<?php echo $epin['id'] ?>" target="_blank"><button type="submit" class="btn btn-outline-success px-1 btn-xs"><i class="fi fi-rr-eye"></i></button></a>

                                        <a href="<?=getConfig("url")?>/admin/edit/product/<?php echo $epin['id'] ?>"><button type="submit" class="btn btn-outline-info px-1 btn-xs"><i class="fi fi-rr-pencil"></i></button></a>

                                        <a href="<?=getConfig("url")?>/admin/delete/product/<?php echo $epin['id'] ?>"><button type="submit" class="btn btn-outline-danger px-1 btn-xs"><i class="fi fi-rr-trash"></i></button></a>

                                    </td>
                                </tr>

                                <?php
                            }
                            ?>

                            </tbody>
                            <tfoot>


                            <tr>
                                <th>ID</th>
                                <th>Başlık</th>
                                <th>Kategori</th>
                                <th>Stok</th>
                                <th>Fiyat</th>
                                <th></th>
                            </tr>


                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- end page content-->
    </div>
    <!--end page content wrapper-->

<?php require_once 'footer.php'; ?>