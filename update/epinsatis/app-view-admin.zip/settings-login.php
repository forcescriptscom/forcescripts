<?php
require_once 'app/view/admin/header.php';
?>

<?php
if (@$_GET['durum'] == "basarili") {
    ?>

    <script>
        swal("Başarılı!", "Değişiklikler başarı ile kaydedildi!", "success");
    </script>

        <?php
}

?>

<?php
if (@$_GET['durum'] == "basarisiz") {
    ?>

    <script>
        swal("Başarısız!", "Değişiklikler bilinmeyen bir nedenden dolayı kaydedilemedi!", "error");
    </script>

    <?php
}

?>

    <!-- start page content wrapper-->
    <div class="page-content-wrapper">
        <!-- start page content-->
        <div class="page-content">

            <!--start breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">Ayarlar</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0 align-items-center">
                            <li class="breadcrumb-item"><a href="javascript:;"><i class="fi fi-sr-id-card-clip-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Giriş/Kayıt Ayarları</li>
                        </ol>
                    </nav>
                </div>

            </div>
            <!--end breadcrumb-->


            <div class="row">
                <div class="col-xl-12 mx-auto">
                    <h6 class="mb-0 text-uppercase">Hızlı Giriş Ayarları</h6>
                    <hr>
                    <div class="card">
                        <form action="<?= getConfig('url') ?>/post/89028/1829" method="post">
                        <div class="card-body">

                            <div class="row">
                            <div class="col-md-4">

                                <label for="google_id" class="form-label">Google Client Id <a target="_blank" href="https://youtu.be/s0Ts7KoyqTA"><i title="Doldurulmazsa google ile girişler açılmaz. Nasıl bulunacağı ile ilgili video için tıklayın." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i> </a></label>
                                <input class="form-control mb-3" value="<?= getConfig('google_id') ?>" name="client_id" id="google_id" type="text" placeholder="Google client id bilginizi giriniz.">

                            </div>


                            <div class="col-md-4">

                                <label for="google_secret" class="form-label">Google Client Secret Id <a target="_blank" href="https://youtu.be/s0Ts7KoyqTA"><i title="Doldurulmazsa google ile girişler açılmaz. Nasıl bulunacağı ile ilgili video için tıklayın." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i> </a></label>
                                <input class="form-control mb-3" name="secret_id" value="<?= getConfig('google_secret') ?>" id="google_secret" type="text" placeholder="Google client secret id bilginizi giriniz.">

                            </div>

                                <div class="col-md-4">

                                    <label  class="form-label">Google Redirect Url <i title="Google console'a girilmesi gereken redirect urldir." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"></i></label>
                                    <input class="form-control mb-3" readonly type="text" value="<?= getConfig('url') ?>/google-redirect" placeholder="Google rewrite url.">

                                </div>

                            </div>


                            <button type="submit" class="btn btn-outline-success px-5 radius-30 col-12">Kaydet</button>


                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12 mx-auto">
                    <h6 class="mb-0 text-uppercase">Hızlı Giriş Ayarları</h6>
                    <hr>
                    <div class="card">
                        <form action="<?= getConfig('url') ?>/post/0123548/84752302" method="POST">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-4">

                                        <label for="google_id" class="form-label">Custom URL <a target="_blank" href="https://youtu.be/s0Ts7KoyqTA"><i title="Discorda girilmesi gereken url." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i> </a></label>
                                        <input class="form-control mb-3" value="<?= getConfig('url') ?>/redirect/discord"  type="text" readonly>

                                    </div>


                                    <div class="col-md-4">

                                        <label for="dc_client_id" class="form-label">Discord Client Id <a target="_blank" href="https://youtu.be/s0Ts7KoyqTAm"><i title="Doldurulmazsa discord ile girişler açılmaz. Nasıl bulunacağı ile ilgili video için tıklayın." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i> </a></label>
                                        <input class="form-control mb-3" name="dc_client_id" value="<?= getConfig('dc_client_id') ?>" id="dc_client_id" type="text" placeholder="Discord client id bilginizi giriniz.">

                                    </div>

                                    <div class="col-md-4">

                                        <label for="dc_client_secret" class="form-label">Discord Client Secret Id <a target="_blank" href="https://youtu.be/s0Ts7KoyqTA"><i title="Doldurulmazsa discord ile girişler açılmaz. Nasıl bulunacağı ile ilgili video için tıklayın." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i> </a></label>
                                        <input class="form-control mb-3" name="dc_client_secret" value="<?= getConfig('dc_client_secret') ?>" id="dc_client_secret" type="text" placeholder="Discord client secret id bilginizi giriniz.">

                                    </div>

                                </div>


                                <button type="submit" class="btn btn-outline-success px-5 radius-30 col-12">Kaydet</button>


                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 mx-auto">
                    <h6 class="mb-0 text-uppercase">Giriş Güvenliği HCaptcha !! ÖNEMLİ !!</h6>
                    <p>Sitenin giriş sayfasında güvenlik için girilmesi gerekmektedir.</p>
                    <hr>
                    <div class="card">
                        <form action="<?= getConfig('url') ?>/post/205564/021587" method="post">
                        <div class="card-body">

                            <div class="row">
                            <div class="col-md-4">

                                <label for="site_key" class="form-label">HCaptcha Site Key <i title="hcaptcha.com üzerinden alınabilir." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i></label>
                                <input class="form-control mb-3" value="<?= getConfig('h_site_key') ?>" name="site_key" id="site_key" type="text" placeholder="HCaptcha site key bilginizi giriniz.">

                            </div>


                            <div class="col-md-4">

                                <label for="secret_key" class="form-label">HCaptcha Secret Key <i title="hcaptcha.com üzerinden alınabilir." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"> Nasıl Alınır?</i></label>
                                <input class="form-control mb-3" name="secret_key" value="<?= getConfig('h_secret_key') ?>" id="secret_key" type="text" placeholder="HCaptcha secret key bilginizi giriniz.">

                            </div>



                            </div>


                            <button type="submit" class="btn btn-outline-success px-5 radius-30 col-12">Kaydet</button>


                        </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 mx-auto">
                    <h6 class="mb-0 text-uppercase">Diğer Kayıt Ayarları</h6>
                    <hr>
                    <div class="card">
                        <form action="<?= getConfig('url') ?>/post/78690/4523" method="post">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-4">

                                        <label for="asd" class="form-label">Yasaklı Kullanıcı Adları <i title="Yasaklanmış kullanıcı adlarını virgül -,-  ile ayırarak giriniz. Girilen kullanıcı adları ile kayıtlar reddedilecektir." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"></i> </label>
                                        <input class="form-control mb-3" value="<?= getConfig('banned_username') ?>" name="banned_username" id="asd" type="text" placeholder="Yasaklanacak kullanıcı adlarını virgül -,- ile ayırarak giriniz.">

                                    </div>


                                    <div class="col-md-4">

                                        <label for="dsa" class="form-label">Yasaklı Epostalar <i title="Yasaklanmış eposta adreslerini virgül -,- ile ayırarak giriniz. Girilen eposta adresleri ile kayıtlar reddedilecektir." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"></i></label>
                                        <input class="form-control mb-3" name="banned_email" value="<?= getConfig('banned_email') ?>" id="dsa" type="text" placeholder="Yasaklanacak eposta adreslerini virgül -,- ile ayırarak giriniz.">

                                    </div>

                                    <div class="col-md-4">

                                        <label for="bsd" class="form-label">Yasaklı Telefon Numaraları <i title="Yasaklanmış telefon numaralarını virgül -,- ile ayırarak giriniz. Girilen telefon numaraları ile kayıtlar reddedilecektir." class="fi fi-sr-interrogation"  data-bs-toggle="tooltip" data-bs-placement="right"></i></label>
                                        <input id="bsd" class="form-control mb-3" type="text" name="banned_phone" value="<?= getConfig('banned_phone') ?>" placeholder="Yasaklanacak telefon numaralarını virgül -,- ile ayırarak giriniz.">

                                    </div>

                                </div>


                                <button type="submit" class="btn btn-outline-success px-5 radius-30 col-12">Kaydet</button>


                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>




<?php
require_once 'app/view/admin/footer.php';
?>