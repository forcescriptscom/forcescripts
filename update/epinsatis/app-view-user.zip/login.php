<?php

include 'app/view/user/header.php';



if (!empty($_SESSION['kullanici'])) {

    header("Location:../");

    exit();

}

?>

<?php
if(!empty(getConfig('h_site_key')) and !empty('h_secret_key')){
    ?>
    <script src='https://www.hCaptcha.com/1/api.js' async defer></script>
    <?php
}


?>

<?php

if (@$_GET['durum'] == "captcha") {

?>


    <script>
        swal("Başarısız!", "Captcha ile ilgili bir hata oluştu!", "error");
    </script>

        <?php


}

?>


<?php

if (@$_GET['durum'] == "boscaptcha") {

?>


    <script>
        swal("Başarısız!", "Lütfen Bot Doğrulamasını Tamamlayın!", "error");
    </script>

        <?php


}

?>

<?php

if (@$_GET['durum'] == "yanlis") {

?>


    <script>
        swal("Başarısız!", "Girdiğiniz mail/kullanıcı adı veya şifreniz yanlıştır.!", "error");
    </script>

        <?php


}

?>



    <!-- main-area -->

    <main>



        <!-- breadcrumb-area -->

        <section class="breadcrumb-area breadcrumb-bg">

            <div class="container">

                <div class="row justify-content-center">

                    <div class="col-lg-6 col-md-8">

                        <div class="breadcrumb-content text-center">

                            <h3 class="title">Giriş Yap</h3>

                        </div>

                    </div>

                </div>

            </div>

        </section>

        <!-- breadcrumb-area-end -->





        <!-- welcome-area -->

        <section class="login-welcome-area">

            <div class="container">

                <div class="row">

                    <div class="col-12">

                        <div class="login-welcome-wrap">

                            <div class="login-welcome-content">

                                <h2 class="title">Kolay Giriş</h2>

                                <p><?= getConfig('firma') ?> sitemize aşağıdan kolay bir şekilde giriş yapabilirsiniz. Kayıt olmadıysanız<a href="./register"> buraya</a> tıklayarak kayıt olabilirsiniz.</p>

                            </div>

                            <div class="welcome-rating">

                                <img src="assets/user/img/icons/three_star.png" alt="">

                            </div>

                        </div>

                    </div>

                </div>

                <div class="row">

                    <div class="col-md-6">

                        <div class="signup-form-wrap">

                            <h4 class="title">Giriş</h4>

                            <form action="./login/giris" method="post">

                                <div class="form-grp">

                                    <label for="fName">Eposta/Kullanıcı Adı</label>

                                    <input type="text" required name="eposta" placeholder="Eposta veya Kullanıcı Adı giriniz." id="fName">

                                </div>

                                <div class="form-grp">

                                    <label for="lName">Şifre</label>

                                    <input type="password" required name="sifre" placeholder="Şifre giriniz." id="lName">

                                </div>

                                <div class="form-check">

                                    <input class="form-check-input" name="remember-me" type="checkbox" value="" id="flexCheckDefault">

                                    <label class="form-check-label" for="flexCheckDefault">Beni Hatırla (1 Hafta Kaydedilir.)</label>

                                </div>
<br>
<?php
if(!empty(getConfig('h_site_key')) and !empty('h_secret_key')){
    ?>
    <div class="h-captcha" data-sitekey="<?php echo getConfig('h_site_key'); ?>"></div>

    
    <?php
}


?>

                                <div class="form-btn-wrap">

                                    <button class="btn signup" name="giris">Giriş Yap</button>

                                </div>

                            </form>

                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="another-way-signup">

                            <h4 class="title">Diğer Giriş Yapma Yolları</h4>

                            <p>Aktif ise aşağıdan hızlı giriş yolları ile de giriş yapabilirsiniz.</p>




                            <?php

                            if (!empty(getConfig('google_id')) and !empty(getConfig('google_secret'))) {

                                ?>



                                <ul class="another-way-list">

                                    <li><a href="./login/giris/google"><img width="25" height="21" src="assets/user/img/icons/google.png" alt="">Google <span>Popüler</span></a></li>



                                </ul>

                                <?php

                            }

                            if (!empty(getConfig('dc_client_id')) and !empty(getConfig('dc_client_secret'))) {

                                ?>


                                <ul class="another-way-list">

                                    <li><a href="./login/giris/discord"><img width="25" height="21" src="<?=getConfig("url")?>/uploads/diger/discord.png" alt="">Discord <span>Popüler</span></a></li>



                                </ul>

                                <?php


                            }
                            ?>








                        </div>

                    </div>

                </div>

            </div>

        </section>

        <!-- welcome-area-end -->



    </main>

    <!-- main-area-end -->





<?php

include 'app/view/user/footer.php';

?>