<?php
require_once "header.php";


if (@$_GET['submit'] !== null) {
    $kategoriler=array();
}
?>


    <style>
        .center {
            text-align: center;
        }

        .pagination {
            display: inline-block;
        }

        .pagination a {
            color: black;
            float: left;
            background-color: whitesmoke;
            padding: 8px 16px;
            text-decoration: none;
            transition: background-color .3s;
            border: 1px solid #ddd;
            margin: 0 4px;
        }

        .pagination a.active {
            background-color: #4CAF50;
            color: white;
            border: 1px solid #4CAF50;
        }

        .pagination a:hover:not(.active) {background-color: #ddd;}
    </style>

    <!-- main-area -->

    <main>



        <!-- breadcrumb-area -->

        <section class="breadcrumb-area breadcrumb-bg">

            <div class="container">

                <div class="row justify-content-center">

                    <div class="col-lg-6 col-md-8">

                        <div class="breadcrumb-content text-center">

                            <h3 class="title">Mağaza</h3>

                        </div>

                    </div>

                </div>

            </div>

        </section>

        <!-- breadcrumb-area-end -->





        <!-- browse-category-area -->

        <div class="browse-category-area pt-80 pb-50">

            <div class="container">

                <div class="row">

                    <div class="col-xl-3 col-lg-4">

                        <aside class="browse-category-sidebar">
                            <form action="" method="get" class="create-item-form sidebar-price-filter">


                                <div class="widget category-widget">

                                    <h4 class="category-widget-title">Stok Durumu</h4>

                                    <div class="widget-inner">


                                        <div class="form-check">
                                            <input <?php

                                            if (@$_GET['submit'] !== null) {
                                                if (@$_GET["stok_var"] == "on") {
                                                    echo "checked";
                                                }
                                            }else{
                                                echo "checked";
                                            }

                                            ?> class="form-check-input" type="checkbox" name="stok_var" id="flexRadioDefault1">
                                            <label class="form-check-label" for="flexRadioDefault1">Stok Var </label>
<br>
                                            <input <?php

                                            if (@$_GET['submit'] !== null) {
                                                if (@$_GET["stok_yok"] == "on") {
                                                    echo "checked";
                                                }
                                            }else{
                                                echo "checked";
                                            }

                                            ?> class="form-check-input" type="checkbox" name="stok_yok" id="flexRadioDefault">
                                            <label class="form-check-label" for="flexRadioDefault">Stok Yok</label>
                                        </div>




                                    </div>

                                </div>

                                <div class="widget category-widget">

                                    <h4 class="category-widget-title">Kategori</h4>

                                    <div class="widget-inner">
                                        <style>
                                            .kaydirma-alani {
                                                width: 200px;
                                                height: 100px;
                                                overflow: auto;
                                            }
                                        </style>

                                        <div class="form-check kaydirma-alani">

                                            <?php
                                            $cat=$db->prepare("SELECT * FROM epin_kategori order by id DESC");
                                            $cat->execute();
                                            while ($kategori=$cat->fetch(PDO::FETCH_ASSOC)) {
                                            ?>

                                            <input <?php
                                            $asd2="kategori-".$kategori['id'];
                                            if (@$_GET['submit'] !== null) {
                                                if (@$_GET["$asd2"] == "on") {
                                                    array_push($kategoriler, $kategori['id']);
                                                    echo "checked";
                                                }
                                            }else{
                                                echo "checked";
                                            }


                                            ?> class="form-check-input" type="checkbox" name="kategori-<?php echo $kategori['id'] ?>" id="<?php echo $kategori['id'] ?>">
                                            <label class="form-check-label" for="<?php echo $kategori['id'] ?>"><?php echo $kategori['baslik'] ?></label>

                                            <br>

                                                <?php
                                            }


                                            if (empty($kategoriler) && @$_GET['submit'] !== null) {
                                                header("Location:$url/shop");
                                            }
                                                ?>

                                        </div>




                                    </div>

                                </div>

                                <div class="widget category-widget">

                                    <h4 class="category-widget-title">Fiyat Aralığı</h4>

                                    <div class="widget-inner">



                                        <div class="form-grp">

                                            <input type="number" <?php

                                            if (@$_GET['submit'] !== null) {
                                                if ($_GET['min'] > 0) {
                                                    echo 'value="'.$_GET['min'].'"';
                                                }else{
                                                    echo 'value="0"';
                                                }
                                            }else{
                                                echo 'value="0"';
                                            }


                                            ?> name="min" placeholder="Min. <?=getConfig("kur")?>">

                                            <span class="to">İle</span>

                                            <input <?php

                                            if (@$_GET['submit'] !== null) {
                                                if ($_GET['max'] > 0) {
                                                    echo 'value="'.$_GET['max'].'"';
                                                }
                                            }

                                            ?> type="number" name="max" placeholder="Max. <?=getConfig("kur")?>">

                                        </div>


                                    </div>

                                </div>
<div style="display: flex;
      justify-content: center;
      align-items: center;
">
                                <button class="btn btn-success" name="submit" type="submit">Filtrele</button>
</div>
                            </form>

                        </aside>



                    </div>

                    <div class="col-xl-9 col-lg-8">

                        <div class="row justify-content-center">

                            <?php

                            $kac=12;

                            if (!empty(@$_GET['p'])) {
                                $sayfa=$_GET['p'];
                            }else{
                                $sayfa=1;
                            }

                            if (@$_GET['submit'] !== null) {
                                $sql = "SELECT * FROM epin WHERE 1";


                                if (@$_GET['stok_var'] != null && @$_GET['stok_yok'] != null) {
                                    // tüm her şey aranacak



                                    if (!empty($kategoriler)) {
                                        $placeholders = implode(',', $kategoriler);
                                        $filtreKat= " AND kategori IN ($placeholders)";
                                    }else{
                                        $filtreKat="";
                                    }

                                    if (@$_GET['min'] >= 0 and !empty(@$_GET['min'])) {
                                        $filtreMin= " AND tutar >= ".$_GET['min'];
                                    }else{
                                        $filtreMin="";
                                    }

                                    if (@$_GET['max'] >= 0 and !empty(@$_GET['max'])) {
                                        $filtreMax= " AND tutar <= ".$_GET['max'];
                                    }else{
                                        $filtreMax="";
                                    }

                                    $select= $sql.$filtreKat.$filtreMin.$filtreMax." order by id DESC limit :first_record, :page_count";

                                    $offset = ($sayfa - 1) * $kac;

                                    $yz=$db->prepare("$select");
                                    $yz->bindParam(":first_record", $offset, PDO::PARAM_INT);
                                    $yz->bindParam(":page_count", $kac, PDO::PARAM_INT);
                                    $yz->execute();
                                    $say=$yz->rowCount();



                                    $toplamsayfa=ceil($say/$kac);


                                }elseif (@$_GET['stok_var'] != null && @$_GET['stok_yok'] == null) {
                                    // sadece stok olanlar
                                    $stok=" AND hesap != ''";

                                    if (!empty($kategoriler)) {
                                        $placeholders = implode(',', $kategoriler);
                                        $filtreKat= " AND kategori IN ($placeholders)";
                                    }else{
                                        $filtreKat="";
                                    }

                                    if (@$_GET['min'] >= 0 and !empty(@$_GET['min'])) {
                                        $filtreMin= " AND tutar >= ".$_GET['min'];
                                    }else{
                                        $filtreMin="";
                                    }

                                    if (@$_GET['max'] >= 0 and !empty(@$_GET['max'])) {
                                        $filtreMax= " AND tutar <= ".$_GET['max'];
                                    }else{
                                        $filtreMax="";
                                    }

                                    $select= $sql.$filtreKat.$filtreMin.$filtreMax.$stok." order by id DESC limit :first_record, :page_count";

                                    $offset = ($sayfa - 1) * $kac;

                                    $yz=$db->prepare("$select");
                                    $yz->bindParam(":first_record", $offset, PDO::PARAM_INT);
                                    $yz->bindParam(":page_count", $kac, PDO::PARAM_INT);
                                    $yz->execute();
                                    $say=$yz->rowCount();


                                    $toplamsayfa=ceil($say/$kac);


                                }elseif (@$_GET['stok_var'] == null && $_GET['stok_yok'] != null) {
                                    // sadece stok olmayanlar

                                    $stok=" AND hesap IS NULL OR hesap = ''";

                                    if (!empty($kategoriler)) {
                                        $placeholders = implode(',', $kategoriler);
                                        $filtreKat= " AND kategori IN ($placeholders)";
                                    }else{
                                        $filtreKat="";
                                    }

                                    if (@$_GET['min'] >= 0 and !empty(@$_GET['min'])) {
                                        $filtreMin= " AND tutar >= ".$_GET['min'];
                                    }else{
                                        $filtreMin="";
                                    }

                                    if (@$_GET['max'] >= 0 and !empty(@$_GET['max'])) {
                                        $filtreMax= " AND tutar <= ".$_GET['max'];
                                    }else{
                                        $filtreMax="";
                                    }

                                    $select= $sql.$filtreKat.$filtreMin.$filtreMax.$stok." order by id DESC limit :first_record, :page_count";
                                    $offset = ($sayfa - 1) * $kac;


                                    $yz=$db->prepare("$select");
                                    $yz->bindParam(":first_record", $offset, PDO::PARAM_INT);
                                    $yz->bindParam(":page_count", $kac, PDO::PARAM_INT);
                                    $yz->execute();
                                    $say=$yz->rowCount();


                                    $toplamsayfa=ceil($say/$kac);


                                }else{
                                    // ikiside seçilmemiş
                                    $url=getConfig("url");
                                    header("Location:$url/shop");
                                }





                            }else{

                                $yz=$db->prepare("SELECT * FROM epin");
                                $yz->execute();
                                $say=$yz->rowCount();

                                $offset = ($sayfa - 1) * $kac;

                                $select="SELECT * FROM epin order by id DESC limit :first_record, :page_count";
                                $toplamsayfa=ceil($say/$kac);

                            }



                            ?>

                            <?php

                            $urun=$db->prepare("$select");
                            $urun->bindParam(":first_record", $offset, PDO::PARAM_INT);
                            $urun->bindParam(":page_count", $kac, PDO::PARAM_INT);
                            $urun->execute();
                            while ($cek=$urun->fetch(PDO::FETCH_ASSOC)) {
                            ?>

                            <div class="col-xl-4 col-md-6 col-sm-6">

                                <div class="top-collection-item" <?php if ($cek['vip'] == 1) { echo 'style="border: 1px solid yellow"'; } ?>>
                                    <div class="collection-item-top">
                                        <ul>

                                        </ul>
                                    </div>
                                    <div class="collection-item-thumb">
                                        <a href="<?=getConfig("url")?>/epin/<?php echo replace_tr($cek['baslik']); ?>/<?php echo $cek['id']; ?>"><img width="250px" height="250px" src="<?=getConfig("url")?>/uploads/urunler/<?php echo $cek['resim'] ?>" alt=""></a>
                                    </div>
                                    <div class="collection-item-content">
                                        <h5 <?php if ($cek['vip'] == 1) { echo 'style="color: yellow"'; } ?> class="title"><a href="<?=getConfig("url")?>/epin/<?php echo replace_tr($cek['baslik']); ?>/<?php echo $cek['id']; ?>"><?php echo $cek['baslik'] ?></a> <span class="price"><?php echo $cek['tutar'] ?> <?=getConfig("kur")?></span></h5>
                                    </div>
                                    <div class="collection-item-bottom">
                                        <ul>
                                            <li ><p style="font-size: 13px"><?php

                                                    echo substr($cek['kisa_aciklama'],0,80)."...";

                                                    ?></p></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                                <?php
                            }
                                ?>

                        </div>

                        <?php

if ($say != 0) {

                            if ($sayfa > $toplamsayfa || $sayfa < 1) {
                                $gelenurl=getConfig("url");
                                header("Location:$gelenurl/blog");
                                exit();
                            }
                            ?>

    <div class="center">
        <div class="pagination">
            <?php if ($sayfa > 1) { ?>
                <a href="<?php
                if (@$_GET['submit'] !== null) {
                    echo getConfig("url") . $_SERVER['REQUEST_URI'] . '&p=' . ($sayfa - 1);
                } else {
                    echo '?p=' . ($sayfa - 1);
                }
                ?>">&laquo; Geri</a>
            <?php } ?>

            <?php if ($sayfa > 1) { ?>
                <a href="?<?php
                if (@$_GET['submit'] !== null) {
                    echo getConfig("url") . $_SERVER['REQUEST_URI'] . '&p=' . ($sayfa - 1);
                } else {
                    echo '?p=' . ($sayfa - 1);
                }
                ?>"><?php echo $sayfa - 1; ?></a>
            <?php } ?>

            <a href="<?php
            if (@$_GET['submit'] !== null) {
                echo getConfig("url") . $_SERVER['REQUEST_URI'] . '&p=' . $sayfa;
            } else {
                echo '?p=' . $sayfa;
            }
            ?>" class="active"><?php echo $sayfa ?></a>

            <?php if ($sayfa != $toplamsayfa) { ?>
                <a href="<?php
                if (@$_GET['submit'] !== null) {
                    echo getConfig("url") . $_SERVER['REQUEST_URI'] . '&p=' . ($sayfa + 1);
                } else {
                    echo '?p=' . ($sayfa + 1);
                }
                ?>"><?php echo $sayfa + 1; ?></a>
            <?php } ?>

            <?php if ($sayfa != $toplamsayfa) { ?>
                <a href="<?php
                if (@$_GET['submit'] !== null) {
                    echo getConfig("url") . $_SERVER['REQUEST_URI'] . '&p=' . ($sayfa + 1);
                } else {
                    echo '?p=' . ($sayfa + 1);
                }
                ?>">&raquo; İleri</a>
            <?php } ?>
        </div>
    </div>

                            <?php
}
                        ?>
                    </div>

                </div>

            </div>

        </div>

        <!-- browse-category-area-end -->





    </main>

    <!-- main-area-end -->





<?php
require_once "footer.php";
?>